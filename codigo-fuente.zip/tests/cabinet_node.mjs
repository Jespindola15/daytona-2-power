// One Daytona 2 cabinet in Node (WebAssembly core, no video) linked through the relay.
// Usage: node cabinet_node.mjs <name> <wsurl> <frames> <outdir> [host:N]
// Env: ROM, XML, NVDIR, SCRIPT ("frame:KEY+,frame:KEY-" relative to link-ready frame), SHOTS (every N frames)
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { D2Link } = require('../web/netlink.js');
const createD2 = require(new URL('../core/out/wasm/headless.js', import.meta.url).pathname);
const [name, wsurl, framesArg, out, hostArg] = process.argv.slice(2);
const frames = +framesArg; mkdirSync(out, { recursive: true });
const ROM = process.env.ROM, XML = process.env.XML, NVDIR = process.env.NVDIR;
const hostN = hostArg ? +hostArg.split(':')[1] : 0;
const lines = []; const log = (s) => { lines.push(s); if (/\[(net|link|cab)\]|rror/.test(s)) console.log(`${name} ${s}`); };

const ws = new WebSocket(wsurl.includes("/ws") ? `${wsurl}?name=${name}` : `${wsurl}?room=TEST&name=${name}`); ws.binaryType = 'arraybuffer';
let link, wake = null, started = null, t0 = Date.now();
ws.onmessage = (e) => {
  if (typeof e.data !== 'string') { link?.onMessage(e.data); if (wake) { const w = wake; wake = null; w(); } return; }
  const m = JSON.parse(e.data);
  if (m.t === 'room') {
    if (!hostN) ws.send(JSON.stringify({ t: 'ready', v: true }));
    else if (m.players.length >= hostN && m.players.every((p) => p.host || p.ready)) ws.send(JSON.stringify({ t: 'start' }));
  } else if (m.t === 'start') started?.(m);
  else if (m.t === 'pong') ws.send(JSON.stringify({ t: 'rtt', ms: Date.now() - m.ts }));
  else if (m.t === 'drop') { log(`[link] se cortó: ${m.name}`); link?.breakLink(); }
  else if (m.t === 'error') log('[link] error ' + m.msg);
};
ws.onopen = () => ws.send(JSON.stringify({ t: 'ping', ts: Date.now() }));
const cfg = await new Promise((r) => { started = r; });
log(`[cab] máquina ${cfg.index + 1}/${cfg.num}, demora ${cfg.delay}, pilotos ${cfg.roster.join(',')}`);

const M = await createD2({ print: log, printErr: log });
M.FS.mkdir('/rom'); M.FS.mkdir('/out');
M.FS.writeFile('/rom/z.zip', readFileSync(ROM)); M.FS.writeFile('/rom/g.xml', readFileSync(XML));
M.FS.writeFile('/rom/n.nv', readFileSync(`${NVDIR}/car${cfg.index + 1}.nv`));
link = new D2Link(M, (m) => ws.send(m));
link.config(cfg.index, cfg.num, cfg.delay);
if (M.ccall('d2_init', 'number', ['string', 'string', 'string'], ['/rom/z.zip', '/rom/g.xml', '/rom/n.nv'])) process.exit(1);
const run = M.cwrap('d2_run', 'number', ['number']), key = M.cwrap('d2_key', null, ['string', 'number']);
const dump = M.cwrap('d2_dump2d', null, ['string']);
// script relative to the frame the link became ready
const script = (process.env.SCRIPT || '').split(',').filter(Boolean).map((s) => { const [f, k] = s.split(':'); return { f: +f, k: k.slice(0, -1), d: k.endsWith('+') }; });
const every = +(process.env.SHOTS || 300);
let readyAt = -1, tRun = 0, si = 0;
for (let f = 0; f < frames; f++) {
  while (!link.canRun()) { const tw = Date.now(); link.waits++; await new Promise((r) => { wake = r; setTimeout(r, 200); }); link.waitMs += Date.now() - tw; }
  if (readyAt < 0 && M._d2_net_state() === 3) { readyAt = f; log(`[link] listo en cuadro ${f} (${((Date.now() - t0) / 1000).toFixed(1)} s)`); }
  if (readyAt >= 0) while (si < script.length && script[si].f <= f - readyAt) { key(script[si].k, script[si].d ? 1 : 0); si++; }
  link.beforeRun();
  const t = performance.now(); run(1); tRun += performance.now() - t;
  link.afterRun();
  if ((f + 1) % every === 0) { dump(`/out/${name}_${f + 1}.ppm`); if (f % 600 < every) log(`[cab] cuadro ${f + 1} ${JSON.stringify(link.stats())}`); }
  if (f % 60 === 0) await new Promise((r) => setImmediate(r));
}
const wall = (Date.now() - t0) / 1000;
log(`[cab] FIN ${frames} cuadros, CPU ${(tRun / frames).toFixed(2)} ms/cuadro, ${JSON.stringify(link.stats())}, ${wall.toFixed(0)} s`);
for (const f of M.FS.readdir('/out')) if (f.endsWith('.ppm')) writeFileSync(`${out}/${f}`, M.FS.readFile('/out/' + f));
writeFileSync(`${out}/${name}.log`, lines.join('\n'));
ws.close(); process.exit(0);
