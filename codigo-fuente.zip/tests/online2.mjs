// Two real Chrome pages race online through the local Cloudflare runtime (wrangler dev).
import { chromium } from 'playwright';
import { mkdirSync } from 'node:fs';
const out = '/tmp/on2'; mkdirSync(out, { recursive: true });
const SALAS = process.env.SALAS || 'http://localhost:8790';
const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', headless: true, args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--disable-background-timer-throttling', '--disable-renderer-backgrounding'] });
async function open(name) {
  const ctx = await browser.newContext({ viewport: { width: 1100, height: 760 } });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => console.log(name, 'ERROR', e.message));
  page.on('console', (m) => { const t = m.text(); if (/\[(net|online)\]|rror/.test(t)) console.log(name, t.slice(0, 200)); });
  await page.route('**/config.js', (r) => r.fulfill({ contentType: 'text/javascript', body: `window.D2_SALAS_URL='${SALAS}';` }));
  await page.goto('http://localhost:8642/');
  await page.evaluate(() => localStorage.setItem('daytona2.opts', JSON.stringify({ res: '1' })));
  await page.reload();
  await page.waitForSelector('#zipPick', { state: 'attached' });
  await page.setInputFiles('#zipPick', '/home/claude/d2run/roms/dayto2pe.zip');
  await page.waitForFunction(() => window.__ready, null, { timeout: 120000 });
  await page.evaluate(() => window.__send({ t: 'skip3d', on: true }));
  return page;
}
const A = await open('A'), B = await open('B');
console.log('ambas cargadas');
await A.mouse.move(500, 300); await A.click('#btnRooms');
await A.fill('#netName', 'Joaco'); await A.click('#netCreate');
await A.waitForSelector('.code');
const code = (await A.textContent('.code')).trim(); console.log('sala', code);
await B.mouse.move(500, 300); await B.click('#btnRooms');
await B.fill('#netName', 'Amigo'); await B.fill('#netCode', code); await B.click('#netJoin');
await B.waitForSelector('#netReady'); await B.click('#netReady');
await A.waitForSelector('#netStart:not([disabled])', { timeout: 20000 });
await A.waitForTimeout(3000);   // a few pings
await A.screenshot({ path: `${out}/1_sala.png` });
await A.click('#netStart');
for (const p of [A, B]) { await p.waitForFunction(() => document.body.classList.contains('playing') && window.__perf?.net, null, { timeout: 120000 }); await p.evaluate(() => window.__send({ t: 'skip3d', on: true })); }
console.log('cabinas reiniciadas');
const st = (p) => p.evaluate(() => window.__perf);
for (let i = 0; i < 90; i++) { const a = await st(A); if (a?.net?.state === 3 && (await st(B))?.net?.state === 3) break; await A.waitForTimeout(1000); }
console.log('A', JSON.stringify(await st(A))); console.log('B', JSON.stringify(await st(B)));
const tap = async (p, k) => { await p.keyboard.down(k); await p.waitForTimeout(250); await p.keyboard.up(k); };
const at = async (p, f) => { while ((await st(p)).frame < f) await p.waitForTimeout(300); };
const f0 = (await st(A)).frame;
await tap(A, 'Digit3'); await tap(B, 'Digit3'); await A.waitForTimeout(1500); await tap(A, 'Digit1'); await tap(B, 'Digit1');
await at(A, f0 + 400); for (const p of [A, B]) await p.evaluate(() => window.__send({ t: 'skip3d', on: false }));
await A.waitForTimeout(4000);
await A.locator('#screen').screenshot({ path: `${out}/2_A_curso.png` }); await B.locator('#screen').screenshot({ path: `${out}/2_B_curso.png` });
console.log('A', JSON.stringify(await st(A))); console.log('B', JSON.stringify(await st(B)));
await A.click('#btnRooms'); await A.waitForTimeout(500); await A.screenshot({ path: `${out}/3_panel_carrera.png` });
await browser.close();
