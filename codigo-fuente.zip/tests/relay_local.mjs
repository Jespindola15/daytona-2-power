// Local relay for tests: same Room logic as the Cloudflare Durable Object, over `ws`.
// Usage: node relay_local.mjs [port] [extraLatencyMs]
import { WebSocketServer } from 'ws';
import { Room, newCode } from '../online/relay/room.js';
const port = +(process.argv[2] || 8787), lag = +(process.argv[3] || 0);
const rooms = new Map();
const wss = new WebSocketServer({ port });
wss.on('connection', (ws, req) => {
  const url = new URL(req.url, 'http://x');
  const code = (url.searchParams.get('room') || newCode()).toUpperCase();
  let room = rooms.get(code); if (!room) { room = new Room(code); rooms.set(code, room); }
  // optional artificial one-way latency on the way out (simulates internet distance)
  const send = (m) => { if (ws.readyState !== 1) return; lag ? setTimeout(() => ws.readyState === 1 && ws.send(m), lag) : ws.send(m); };
  const r = room.join(url.searchParams.get('name'), send);
  if (r.error) { ws.send(JSON.stringify({ t: 'error', msg: r.error })); ws.close(); return; }
  const p = r.player;
  ws.on('message', (data, isBinary) => {
    const go = () => { if (isBinary) room.frame(p, data); else { try { room.control(p, JSON.parse(data)); } catch {} } };
    lag ? setTimeout(go, lag) : go();
  });
  ws.on('close', () => { room.leave(p); if (!room.players.length) rooms.delete(code); });
});
console.log(`[relay] ws://localhost:${port} (latencia extra ${lag} ms por tramo)`);
