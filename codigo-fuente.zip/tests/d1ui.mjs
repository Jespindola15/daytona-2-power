import { chromium } from 'playwright';
const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', headless: true });
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
await page.goto('http://localhost:8650/index.html'); await page.waitForTimeout(800);
await page.evaluate(() => { document.getElementById('loadText').textContent = 'Cargando… 64%'; document.getElementById('loadBar').style.width = '64%'; document.getElementById('loadActions').hidden = false; });
await page.screenshot({ path: '/tmp/d1/a.png' });
await page.evaluate(() => {
  document.getElementById('loader').hidden = true;
  const c = document.getElementById('screen'); c.style.width = '1000px'; c.style.height = '750px';
  const g = c.getContext('2d'); const gr = g.createLinearGradient(0, 0, 0, 480); gr.addColorStop(0, '#3a7bd5'); gr.addColorStop(1, '#6a8f3a'); g.fillStyle = gr; g.fillRect(0, 0, 640, 480);
  document.getElementById('settings').hidden = false;
  document.getElementById('roomsBody').innerHTML = '<section><h3>Salas abiertas</h3><div class="room-list"><div class="room"><div><b>Sala de Joaco</b><small>2/6 · código</small></div><button class="btn primary">Entrar</button></div><div class="room"><div><b>Carrera rápida</b><small>4/6</small></div><button class="btn">Entrar</button></div></div><p class="code">KX7Q</p><div class="countdown">3</div></section>';
});
await page.waitForTimeout(600); await page.screenshot({ path: '/tmp/d1/b.png' });
await page.evaluate(() => { document.getElementById('settings').hidden = true; document.getElementById('rooms').hidden = false; });
await page.waitForTimeout(600); await page.screenshot({ path: '/tmp/d1/c.png' });
await browser.close();
