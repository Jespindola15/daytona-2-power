// Opens the web prototype in real Google Chrome (headless), loads the user's
// romset through the file picker, and records logs, speed and screenshots.
// Usage: node chrome_test.mjs <url> <dayto2pe.zip> <outdir>
import { chromium } from 'playwright';
import { writeFileSync, mkdirSync } from 'node:fs';
const [url, zip, out] = process.argv.slice(2);
mkdirSync(out, { recursive: true });
const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', headless: true });
const page = await browser.newPage({ viewport: { width: 1100, height: 900 } });
const lines = [];
page.on('console', (m) => lines.push(m.text()));
await page.goto(url);
lines.push('[chrome] ' + (await browser.version()));
await page.setInputFiles('#zip', zip);
await page.waitForFunction(() => window.__ready, null, { timeout: 120000 });
const shot = async (name) => { await page.locator('#pantalla').screenshot({ path: `${out}/${name}.png` }); };
const press = async (k, ms = 120) => { await page.keyboard.down(k); await page.waitForTimeout(ms); await page.keyboard.up(k); };
await page.waitForTimeout(15000); await shot('01_atract_15s');
const perf1 = await page.evaluate(() => window.__perf);
await page.waitForTimeout(10000); await shot('02_atract_25s');
await press('Digit3'); await page.waitForTimeout(1500); await press('Digit1'); await page.waitForTimeout(3000);
await shot('03_course_select');
await press('ArrowUp'); await page.waitForTimeout(4000); await shot('04_car_select');
await press('ArrowUp'); await page.waitForTimeout(3000); await shot('05_atmt');
await press('ArrowUp'); await page.waitForTimeout(9000); await page.keyboard.down('ArrowUp');
await page.waitForTimeout(6000); await shot('06_carrera_hud'); await page.keyboard.up('ArrowUp');
const perf2 = await page.evaluate(() => window.__perf);
await page.click('#bench');
await page.waitForFunction(() => window.__bench, null, { timeout: 120000 });
const bench = await page.evaluate(() => window.__bench);
await page.screenshot({ path: `${out}/00_pagina.png` });
lines.push(`[chrome] ritmo atract: ${JSON.stringify(perf1)}`, `[chrome] ritmo carrera: ${JSON.stringify(perf2)}`, `[chrome] bench: ${JSON.stringify(bench)}`);
writeFileSync(`${out}/chrome_log.txt`, lines.join('\n') + '\n');
console.log(lines.join('\n'));
await browser.close();
