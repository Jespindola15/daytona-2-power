// Runs the WebAssembly build of the headless Model 3 core in Node (V8, the
// same JS/Wasm engine as Chrome). The romset is read from the user's disk into
// the in-memory filesystem; it is never bundled with the code.
// Usage: node run_node.mjs <dayto2pe.zip> <Games.xml> <nvram.nv> [frames] [dumpdir]
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const [zip, xml, nv, framesArg = '1200', dump] = process.argv.slice(2);
const frames = +framesArg;
const createD2 = require(new URL('../core/out/wasm/headless.js', import.meta.url).pathname);
let t = performance.now();
const M = await createD2({ print: (s) => console.log(s), printErr: (s) => console.error(s) });
console.log(`[node ${process.version}] wasm instantiated in ${(performance.now() - t).toFixed(0)} ms`);
M.FS.mkdir('/rom'); M.FS.mkdir('/out');
M.FS.writeFile('/rom/dayto2pe.zip', readFileSync(zip));
M.FS.writeFile('/rom/Games.xml', readFileSync(xml));
M.FS.writeFile('/rom/dayto2pe.nv', readFileSync(nv));
const init = M.cwrap('d2_init', 'number', ['string', 'string', 'string']);
const run = M.cwrap('d2_run', 'number', ['number']);
const stats = M.cwrap('d2_stats', null, []);
const dump2d = M.cwrap('d2_dump2d', null, ['string']);
const script = M.cwrap('d2_script', null, ['string']);
if (process.env.D2_SCRIPT) script(process.env.D2_SCRIPT);
if (init('/rom/dayto2pe.zip', '/rom/Games.xml', '/rom/dayto2pe.nv')) process.exit(1);
let total = 0;
for (let done = 0; done < frames; done += 60) {
  const ms = run(60); total += ms;
  console.log(`[perf] frames ${done}-${done + 59}: ${ms.toFixed(1)} ms -> ${(60000 / ms).toFixed(1)} emulated fps (${(60000 / ms / 57.524 * 100).toFixed(0)}% of 57.524 Hz)`);
  if ((done + 60) % 300 === 0) { stats(); if (dump) dump2d(`/out/f${done + 60}.ppm`); }
}
console.log(`[perf] TOTAL ${frames} frames in ${total.toFixed(0)} ms = ${(frames * 1000 / total).toFixed(1)} fps average`);
if (dump) {
  mkdirSync(dump, { recursive: true });
  for (const f of M.FS.readdir('/out')) if (f.endsWith('.ppm')) writeFileSync(`${dump}/${f}`, M.FS.readFile('/out/' + f));
}
