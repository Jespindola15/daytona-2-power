// Fase 1 test under SwiftShader: fast-forward with the 3D draw skipped (the
// machine still runs every frame and still uploads textures), then draw real
// 3D frames and capture them. Driven by emulated frame numbers.
import { chromium } from 'playwright';
import { writeFileSync, mkdirSync } from 'node:fs';
const [url, zip, out, res = '1'] = process.argv.slice(2);
mkdirSync(out, { recursive: true });
const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', headless: true,
  args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const page = await browser.newPage({ viewport: { width: 2100, height: 1700 } });
const lines = [];
page.on('console', (m) => { const t = m.text(); if (t.trim() && !/^\s/.test(t)) lines.push(t); });
page.on('pageerror', (e) => lines.push('ERROR ' + e.message));
await page.goto(url);
lines.push('[chrome] ' + browser.version());
await page.selectOption('#res', res);
await page.setInputFiles('#zip', zip);
await page.waitForFunction(() => window.__ready, null, { timeout: 120000 });
const send = (m) => page.evaluate((m) => window.__send(m), m);
const frame = () => page.evaluate(() => +document.getElementById('frame').textContent);
const until = async (f) => { while ((await frame()) < f) await page.waitForTimeout(200); };
const later = async (n) => until((await frame()) + n);
const tap = async (k) => { await page.keyboard.down(k); await later(8); await page.keyboard.up(k); };
const shot = async (name, draw = +(process.env.DRAW || 3)) => {
  await send({ t: 'skip3d', on: false }); await later(draw);
  await page.locator('#pantalla').screenshot({ path: `${out}/${name}.png` });
  lines.push(`[shot] ${name} @ frame ${await frame()} perf ${JSON.stringify(await page.evaluate(() => window.__perf))}`);
  await send({ t: 'skip3d', on: true });
};
await send({ t: 'skip3d', on: true });
for (const f of (process.env.ATTRACT || '700,1000,1300,1600,1900').split(',')) { await until(+f); await shot('atract_f' + f); }
if (process.env.RACE) {
  await tap('Digit3'); await later(60); await tap('Digit1'); await later(150); await shot('sel_1_course');
  await tap('ArrowUp'); await later(200); await shot('sel_2_car');
  await tap('ArrowUp'); await later(150); await shot('sel_3_atmt');
  await tap('ArrowUp'); await later(420); await shot('carrera_1_largada');
  await page.keyboard.down('ArrowUp'); await later(500); await shot('carrera_2');
  await page.keyboard.down('ArrowRight'); await later(60); await page.keyboard.up('ArrowRight'); await later(400); await shot('carrera_3');
  await page.keyboard.up('ArrowUp');
}
writeFileSync(`${out}/chrome_log.txt`, lines.join('\n') + '\n');
console.log(lines.join('\n'));
await browser.close();
