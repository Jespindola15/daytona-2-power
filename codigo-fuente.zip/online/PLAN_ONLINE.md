# Plan de integración: frontend + Cloudflare (Fases 3–4)

## Lo que hace el net board original (según Supermodel)

`Src/Model3/SimNetBoard.cpp` + `NetBoardLink.cpp`:

- Las cabinas forman un **anillo**: cada máquina abre una conexión de salida hacia la siguiente (`AddressOut:PortOut`) y recibe de la anterior (`PortIn`).
- **Arranque.** La máquina que el juego configura como MASTER (TEST → GAME ASSIGNMENTS → LINK ID) hace circular un GUID por el anillo. Así se descubre cuántas máquinas hay (`numMachines`) y qué índice le toca a cada una (`machineIndex`).
- **En juego.** En cada cuadro, cada máquina envía su segmento de la memoria de comunicación (`m_segmentSize` bytes, definido por el juego) y recibe los de las demás. `Receive()` **bloquea** hasta que llega el dato. Es un lockstep estricto: si una máquina se atrasa, frena a todas.
- Daytona 2 está en el grupo "GameType::one" (igual que Scud Race, Sega Rally 2, Harley). Hasta 8 cabinas en el original. El objetivo del proyecto es de 2 a 6.

## Propuesta

1. **Transporte.** Se reemplaza `net_stub.cpp` por un `CNetBoardLink` que habla con JavaScript: `Send()` hace un `postMessage` del bloque al hilo principal, y este lo envía por WebSocket.
2. **Sala en Cloudflare.** Un Durable Object por sala (el mismo patrón que `daytona-salas` de Daytona 1, pero con **otro protocolo**). Mantiene el orden del anillo y reenvía cada bloque al siguiente jugador. No interpreta el contenido: el juego original hace la sincronización.
3. **Bloqueo.** Dos caminos posibles:
   - **(a)** El núcleo corre en un worker con `SharedArrayBuffer` y `Receive()` espera con `Atomics.wait`. Requiere encabezados COOP/COEP (`Cross-Origin-Opener-Policy: same-origin`, `Cross-Origin-Embedder-Policy: require-corp`) en Netlify. Es simple y fiel.
   - **(b)** Se convierte el `RunFrame` de la red en no bloqueante: si falta el dato, ese cuadro no se emula y se reintenta. Exige tocar el lazo principal.

   Se recomienda (a).
4. **Configuración de cada jugador.** El juego necesita que cada cabina tenga su LINK ID (MASTER / SLAVE) y su CAR NUMBER en la NVRAM. Se generan con el mismo guion de test menu usado para la NVRAM USA SINGLE, uno por cada puesto, y la sala asigna el puesto.
5. **Latencia.** Con lockstep por cuadro (17,4 ms), un ping de ida y vuelta mayor que unos 40 ms va a frenar la partida. Opciones a medir en Fase 3:
   - cuadros de colchón en el anillo (permitir N cuadros de retraso);
   - solo partidas entre jugadores cercanos.

   **No se promete** jugabilidad online hasta medirla.
6. **RTC.** Para que las máquinas arranquen iguales, hay que fijar el reloj (RTC72421) a un valor común que reparta la sala.

## Frontend

Se reutiliza la estructura de Daytona 1 (menú, salas, ajustes de video y joystick) en un sitio **separado**:
- la ROM se elige localmente y nunca se sube;
- los ajustes de video se aplican sobre el canvas WebGL2 de la Fase 1;
- `SALAS_URL` apunta a un Worker propio de Daytona 2.

Los secretos de Cloudflare se quedan en `wrangler` / variables de entorno y no van al repositorio.
