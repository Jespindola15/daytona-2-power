# ESTADO — Daytona USA 2 Power Edition en Chrome

Actualizado: 13/11/2026 · Núcleo: Supermodel (trzy/Supermodel, commit `65ec91d6`, 0.4-dev, GPLv3)
Equipo de prueba: contenedor Linux con 2 núcleos Intel Xeon a 2,1 GHz y **sin GPU**. Chrome usa ahí SwiftShader, un WebGL2 por software muy lento.

Cada punto "confirmado" tiene su prueba en `tests/logs/` o en `tests/capturas/`.

## ✅ Confirmado

### Fase 0
| # | Qué | Prueba |
|---|-----|--------|
| 1 | El romset `dayto2pe` está completo: 41/41 archivos propios y 6 heredados de `daytona2`, todos con el CRC32 correcto. | Fase 0.1 |
| 2 | Supermodel nativo arranca la ROM original hasta la carrera. | `capturas/nativo_supermodel/` |
| 3 | **Inglés sin tocar la ROM.** Menú de región oculto: en TEST MENU, mantener START y pulsar VR4 VR4 VR2 VR3 VR1 VR3 VR2, después COUNTRY = USA. | `capturas/nativo_supermodel/menu_region_oculto.png` |
| 4 | NVRAM inicial generada por el propio juego (USA, SINGLE, 0 créditos), con un guion reproducible. | `core/nvram/`, `logs/nvram_usa_single_*` |
| 5 | El núcleo compila a WebAssembly y corre sin video al 184 % de la velocidad real en V8. | `logs/headless_wasm_node.log` |
| 6 | En Chrome, el núcleo sin video mantiene la velocidad real (57,5 fps) con 9–15 ms de CPU por cuadro. | `logs/chrome_wasm.log` |

### Fase 1 — primer cuadro real en Chrome
| # | Qué | Prueba |
|---|-----|--------|
| 7 | **El 3D se dibuja en Chrome con WebGL2**, usando los renderizadores propios de Supermodel (New3D para la GPU Real3D, Render2D para el tile generator y SuperAA), compilados sin fork. La adaptación está en el borde de la API (`core/video_web.cpp`, `core/webshim/`): los shaders GLSL 4.10 se traducen a GLSL ES 3.00 al vuelo. Hay 4 reglas puntuales: una conversión implícita y un índice variable de array de samplers. Todos los shaders que usa el juego compilan en Chrome: el contador de errores da 0. | `logs/chrome_webgl2_fase1.log`, `glslangValidator` |
| 8 | Se ven, desde la ROM original: atract (banderillero, tribunas, cielo, textos), selección de pista, auto y caja con los autos 3D, y la carrera completa (ROLLING START, el auto 41, la pista con su tablero, chispas, el mapa y el HUD en mph). | `capturas/chrome_webgl2/` |
| 9 | Resolución interna elegible: x1 (496×384), x2, x3 y x4 (1984×1536). Se re-rasteriza el 3D a esa resolución; no es un escalado de la imagen. Probado x1 y x2. | `capturas/chrome_webgl2/atract_bandera_x1.png` vs `_x2.png` |
| 10 | **Salto de cuadros sin pérdida.** Si el navegador se atrasa, solo se dibuja el 3D del último cuadro de cada tanda: un OffscreenCanvas solo muestra ese cuadro. Las texturas y la memoria del Real3D se siguen actualizando, así que el juego nunca pierde estado. | `worker.js`, `CProxy3D` en `core/headless.cpp` |

### Fase 2 (en parte)
| # | Qué | Prueba |
|---|-----|--------|
| 11 | **Sonido:** el SCSP y la DSB2 se mezclan a estéreo y se reproducen con un AudioWorklet a 42 280 Hz, que es 735 muestras × 57,524 cuadros/s. Hay una cola de 250 ms como máximo. Se verificó que llegan 735 muestras por cuadro al worklet. No pude escucharlo, porque el contenedor no tiene salida de audio. | `tests/smoke.mjs` |
| 12 | **Joystick** (API Gamepad, mapeo estándar): la palanca es el volante analógico; RT y LT son acelerador y freno analógicos; A B X Y son las vistas VR1–4; Start; Back es moneda; LB y RB bajan y suben la marcha (la caja de 4 marchas sostiene la marcha elegida, como la palanca H del mueble). Hay un joystick virtual en el sistema de entradas de Supermodel. | Código compilado. **No probado con un joystick físico.** |
| 13 | **Récords y ajustes guardados:** la NVRAM se guarda en IndexedDB cada 20 s y se recupera al recargar. Hay un botón para volver a la inicial. | `tests/smoke.mjs` (131 513 bytes guardados y releídos) |

## ⏳ Pendiente

- **Medir en una PC real con GPU. Es la prueba más importante que falta.** En SwiftShader el 3D va lento (1–40 fps según la escena), pero eso no representa una PC con placa de video. Del lado del navegador, armar el cuadro cuesta 1,2–3,4 ms de CPU, así que el límite va a ser la GPU o el driver.
  - Si una PC no llega a 57,5 fps, el salto de cuadros mantiene la velocidad del juego y baja la fluidez.
- Probar el joystick y el sonido con hardware real.
- Pantalla completa, filtros y la interfaz definitiva (menú estilo Daytona 1).
- Determinismo del RTC (fijar el reloj), necesario para el online.
- Al arrancar, el juego pide miles de draw calls por cuadro durante unos segundos (escena todavía sin inicializar). En una GPU real debería pasar rápido; en SwiftShader tarda.

## ⛔ Bloqueado / riesgos conocidos

- **Online (Fase 3):** el transporte del net board es un stub. El original es un anillo lockstep con `Receive()` bloqueante; ver `online/PLAN_ONLINE.md`. No se promete jugabilidad online antes de medir la latencia.
- **Licencia:** Supermodel es GPLv3. El `.wasm` publicado requiere publicar este código fuente. La ROM nunca va en el repositorio ni en el deploy.
- La ruta de quads de New3D no está disponible: WebGL2 no tiene geometry shaders. Se usa la ruta de triángulos, que es la misma que en PC con `QuadRendering=false`.
