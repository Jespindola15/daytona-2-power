# daytona-2-power — Daytona USA 2 Power Edition en el navegador

Este proyecto ejecuta la **ROM original de Sega Model 3** con el núcleo del emulador [Supermodel](https://github.com/trzy/Supermodel) (GPLv3) compilado a WebAssembly. No usa streaming, no es un clon y no imita la física.

**Estado:** Fases 0 y 1 terminadas, con buena parte de la 2 (sonido, joystick, guardado). Ver `ESTADO.md`.

```
core/    arnés headless + build (nativo y WebAssembly), shims y stubs, NVRAM USA/SINGLE
web/     el juego para Chrome: elegís tu dayto2pe.zip y corre en un Web Worker con video WebGL2 (3D + 2D), sonido y joystick
online/  plan de salas (Cloudflare) basado en el net board original
tests/   scripts de prueba (Node y Chrome), logs y capturas reales
```

## La ROM no está incluida
Necesitás tu propio `dayto2pe.zip` (Daytona USA 2 Power Edition, con los 6 archivos heredados de `daytona2`). La página lo lee en tu navegador y **no lo sube a ningún lado**. No lo agregues al repositorio.

## Probar el prototipo web
```
cd web
python -m http.server 8642
```
Abrí http://localhost:8642 en Chrome y elegí el zip.
Antes de elegir el zip podés elegir la resolución interna (x1 a x4).
- Teclado: `3` moneda · `1` start · flechas = volante y pedales · `A S D F` vistas · `Q W E R` marchas (MT) · `5` service · `6` test.
- Joystick: palanca = volante · RT/LT = acelerador/freno · A B X Y = vistas · Start · Back = moneda · LB/RB = bajar/subir marcha.

## Compilar
```
git clone https://github.com/trzy/Supermodel third_party/Supermodel    # commit probado: 65ec91d6
git clone --branch v1.3.1 https://github.com/madler/zlib third_party/zlib   # solo para wasm
cd core
./build.sh native                       # g++
source <emsdk>/emsdk_env.sh
./build.sh wasm                         # núcleo sin video (pruebas en Node)
./build.sh web                          # núcleo con video -> copiar out/web/d2core.* a web/core/
```
En Windows se compila desde WSL.

## Licencia
El núcleo (Supermodel) y los archivos de `core/` derivados de él están bajo GPLv3. Si publicás el `.wasm`, publicá también este código fuente.
