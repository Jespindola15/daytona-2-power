// Web build: Supermodel includes <GL/glew.h> (desktop OpenGL via GLEW).
// In the browser the API is WebGL2 = OpenGL ES 3.0, provided by Emscripten.
#ifndef D2_WEB_GLEW_H
#define D2_WEB_GLEW_H
#include <GLES3/gl3.h>
#ifdef __cplusplus
extern "C" {
#endif
void glDrawBuffer(GLenum buf);           // desktop only -> glDrawBuffers (video_web.cpp)
void glClearDepth(double d);             // desktop double version -> glClearDepthf
#ifdef __cplusplus
}
#endif
#ifndef GL_GEOMETRY_SHADER
#define GL_GEOMETRY_SHADER 0x8DD9        // quad path only; never used (QuadRendering=false)
#endif
#ifndef GL_LINES_ADJACENCY
#define GL_LINES_ADJACENCY 0x000A     // quad path only
#endif
#ifndef GL_BGRA
#define GL_BGRA 0x80E1
#endif
#endif
