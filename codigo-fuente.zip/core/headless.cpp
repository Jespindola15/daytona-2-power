/*
 * headless.cpp — Daytona USA 2 web port, Phase 0 harness.
 *
 * Runs the ORIGINAL Supermodel Model 3 core (PowerPC 603e + Real3D + TileGen +
 * SCSP sound board + DSB2 + drive board) against a user-supplied romset, with
 * NO video output: the 2D/3D renderers are null objects that only count calls.
 * Purpose: measure how fast the emulated hardware runs when compiled to native
 * code vs. WebAssembly, and log real boot progress. It does not draw anything,
 * and it never fakes a Daytona screen.
 *
 * Usage: headless <romset.zip> [frames] [games.xml] [nvram dir]
 * Supermodel is GPLv3; this file is GPLv3 as part of the derived work.
 */
#include <chrono>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <algorithm>
#include <memory>
#include <cmath>
#include <cstdlib>

#include "Supermodel.h"
#include "Util/NewConfig.h"
#include "Util/Format.h"
#include "Util/ConfigBuilders.h"
#include "OSD/FileSystemPath.h"
#include "OSD/Audio.h"
#include "OSD/Video.h"
#include "GameLoader.h"
#include "ROMSet.h"
#include "BlockFile.h"
#include "Model3/Model3.h"
#include "Graphics/Render2D.h"
#include "Graphics/IRender3D.h"
#ifdef D2_VIDEO
#include "Graphics/New3D/New3D.h"
#include "Graphics/SuperAA.h"
#endif
#include "Inputs/Inputs.h"
#include "Inputs/InputSystem.h"
#include "Network/NetProtocol.h"
#define SUPERMODEL_VERSION_STRING_HEADLESS "0.4-dev (d2 headless)"

#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#define D2_EXPORT EMSCRIPTEN_KEEPALIVE
#else
#define D2_EXPORT
#endif

static std::string s_gameXMLFilePath = "Config/Games.xml";
#include "default_config.inc"   // DefaultConfig() copied verbatim from Src/OSD/SDL/Main.cpp

static double nowMs()
{
  using namespace std::chrono;
  return duration<double, std::milli>(steady_clock::now().time_since_epoch()).count();
}

// ---------------------------------------------------------------- audio sink
static unsigned long long s_audioSamples = 0;
static double s_audioEnergy = 0;
void SetAudioCallback(AudioCallbackFPtr, void *) {}
void SetAudioEnabled(bool) {}
void SetAudioType(Game::AudioTypes) {}
Result OpenAudio(const Util::Config::Node &) { return Result::OKAY; }
// Interleaved stereo float [-1,1] collected per run() call; the page drains it
// into an AudioWorklet. Rear channels (quad output) are folded into the front.
static std::vector<float> s_audioOut;
bool OutputAudio(unsigned n, const float *l, const float *r, const float *lr, const float *rr, bool flip)
{
  s_audioSamples += n;
  if (flip) std::swap(l, r), std::swap(lr, rr);
  for (unsigned i = 0; i < n; i++)
  {
    s_audioEnergy += std::fabs(l[i]) + std::fabs(r[i]);
    float L = l[i] + (lr ? lr[i] : 0.f), R = r[i] + (rr ? rr[i] : 0.f);
    if (s_audioOut.size() < 44100 * 2)        // cap: one second
    {
      s_audioOut.push_back(std::max(-1.f, std::min(1.f, L / 32768.f)));
      s_audioOut.push_back(std::max(-1.f, std::min(1.f, R / 32768.f)));
    }
  }
  return false;
}
void CloseAudio() {}
bool BeginFrameVideo() { return true; }
void EndFrameVideo() {}

// ------------------------------------------------------------ null renderers
struct Counters { unsigned long long r2d = 0, frames2d = 0, r3d = 0, texUploads = 0; } s_cnt;

// 2D: the real tile generator draws in software; SoftRender2D.cpp exposes its buffers.
extern std::shared_ptr<TileGenBuffer> g_soft2d[2];

class CNullRender3D : public IRender3D
{
public:
  void RenderFrame() override { s_cnt.r3d++; }
  void BeginFrame() override {}
  void EndFrame() override {}
  void UploadTextures(unsigned, unsigned, unsigned, unsigned, unsigned) override { s_cnt.texUploads++; }
  void AttachMemory(const uint32_t *, const uint32_t *, const uint32_t *, const uint32_t *, const uint16_t *) override {}
  void SetStepping(Game::Stepping) override {}
  Result Init(unsigned, unsigned, unsigned, unsigned, unsigned, unsigned, unsigned) override { return Result::OKAY; }
  void SetSunClamp(bool) override {}
  void SetBlockCulling(bool) override {}
  float GetLosValue(int) override { return 0.0f; }
};

// --------------------------------------------- scripted keyboard input system
// Key names follow Supermodel's own config ("KEY_1", "KEY_UP"...). A script
// (from the command line or from JS) presses them on given frames.
static const char *kKeys[] = { "KEY_1", "KEY_2", "KEY_3", "KEY_4", "KEY_5", "KEY_6", "KEY_UP", "KEY_DOWN",
                               "KEY_LEFT", "KEY_RIGHT", "KEY_A", "KEY_Z", "KEY_Q", "KEY_W", "KEY_E", "KEY_R",
                               "KEY_T", "KEY_Y", "KEY_U", "KEY_I", "KEY_S", "KEY_X", "KEY_D", "KEY_F", nullptr };
static bool s_keyDown[64];

// One virtual joystick fed by the browser Gamepad API (axes -32768..32767).
static int s_joyAxis[8];
static bool s_joyBtn[32];

class CScriptInputSystem : public CInputSystem
{
  KeyDetails m_kd{};
  JoyDetails m_jd{};
public:
  CScriptInputSystem() : CInputSystem("script")
  {
    strcpy(m_kd.name, "script");
    strcpy(m_jd.name, "gamepad (navegador)");
    m_jd.numAxes = 8; m_jd.numPOVs = 0; m_jd.numButtons = 32; m_jd.hasFFeedback = false;
    for (int i = 0; i < 8; i++) { m_jd.hasAxis[i] = true; m_jd.axisName[i][0] = 0; }
  }
  bool InitializeSystem() override { return true; }
  int GetKeyIndex(const char *name) override
  {
    for (int i = 0; kKeys[i]; i++) if (!strcmp(kKeys[i] + 4, name)) return i;   // CInputSystem strips "KEY_"
    for (int i = 0; kKeys[i]; i++) if (!strcmp(kKeys[i], name)) return i;
    return -1;
  }
  const char *GetKeyName(int i) override { return (i >= 0 && kKeys[i]) ? kKeys[i] + 4 : nullptr; }
  bool IsKeyPressed(int, int i) const override { return i >= 0 && i < 64 && s_keyDown[i]; }
  int GetMouseAxisValue(int, int) const override { return 0; }
  int GetMouseWheelDir(int) const override { return 0; }
  bool IsMouseButPressed(int, int) const override { return false; }
  int GetJoyAxisValue(int j, int a) const override { return (j == 0 && a >= 0 && a < 8) ? s_joyAxis[a] : 0; }
  bool IsJoyPOVInDir(int, int, int) const override { return false; }
  bool IsJoyButPressed(int j, int b) const override { return j == 0 && b >= 0 && b < 32 && s_joyBtn[b]; }
  bool ProcessForceFeedbackCmd(int, int, ForceFeedbackCmd) override { return false; }
  int GetNumKeyboards() const override { return 1; }
  int GetNumMice() const override { return 0; }
  int GetNumJoysticks() const override { return 1; }
  const KeyDetails *GetKeyDetails(int) override { return &m_kd; }
  const MouseDetails *GetMouseDetails(int) override { return nullptr; }
  const JoyDetails *GetJoyDetails(int j) override { return j == 0 ? &m_jd : nullptr; }
  bool Poll() override { return true; }
  void SetMouseVisibility(bool) override {}
};

static int keyIndex(const std::string &k)
{
  for (int i = 0; kKeys[i]; i++) if (k == kKeys[i]) return i;
  return -1;
}

// ------------------------------------------------------------------- harness
struct Step { unsigned frame; int key; bool down; };

static Util::Config::Node s_config("Global");
static CModel3 *s_emu = nullptr;
static CInputs *s_inputs = nullptr;
static CRender2D *s_r2d = nullptr;
static CNullRender3D s_r3d;
static std::string s_nvramPath;
static std::vector<Step> s_script;
static size_t s_scriptPos = 0;
static unsigned s_frame = 0;

static void LoadNVRAM()
{
  CBlockFile f;
  if (Result::OKAY != f.Load(s_nvramPath)) { printf("[nvram] none at %s (factory defaults)\n", s_nvramPath.c_str()); return; }
  if (Result::OKAY != f.FindBlock("Supermodel NVRAM State")) { printf("[nvram] invalid file\n"); return; }
  int32_t ver; f.Read(&ver, sizeof(ver));
  s_emu->LoadNVRAM(&f);
  f.Close();
  printf("[nvram] loaded %s (version %d)\n", s_nvramPath.c_str(), ver);
}

static void SaveNVRAM(const char *path)
{
  CBlockFile f;
  if (Result::OKAY != f.Create(path, "Supermodel NVRAM State", "Supermodel Version " + std::string(SUPERMODEL_VERSION_STRING_HEADLESS))) { printf("[nvram] cannot write %s\n", path); return; }
  int32_t ver = 0; f.Write(&ver, sizeof(ver)); f.Write(s_emu->GetGame().name);
  s_emu->SaveNVRAM(&f); f.Close();
  printf("[nvram] saved %s\n", path);
}

// Parses "frame:KEY+,frame:KEY-" (+ = down, - = up).
static void ParseScript(const char *s)
{
  std::string str(s ? s : "");
  size_t p = 0;
  while (p < str.size())
  {
    size_t q = str.find(',', p); if (q == std::string::npos) q = str.size();
    std::string item = str.substr(p, q - p); p = q + 1;
    size_t c = item.find(':'); if (c == std::string::npos || item.size() < c + 3) continue;
    Step st; st.frame = (unsigned)atoi(item.c_str());
    st.down = item.back() == '+';
    st.key = keyIndex(item.substr(c + 1, item.size() - c - 2));
    if (st.key >= 0) s_script.push_back(st);
  }
  std::sort(s_script.begin(), s_script.end(), [](const Step &a, const Step &b) { return a.frame < b.frame; });
}

// Composites the two real tile-generator layers (top over bottom) into RGBA 496x384.
static uint8_t s_rgba[496 * 384 * 4];
static uint32_t Composite2D()
{
  uint32_t hash = 2166136261u;
  for (int y = 0; y < 384; y++)
    for (int x = 0; x < 496; x++)
    {
      uint32_t px = 0;
      for (int l = 1; l >= 0 && !(px >> 24); l--)   // first opaque layer from the top wins
        if (g_soft2d[l]) { uint32_t p = g_soft2d[l]->data[y * 512 + x]; if (p >> 24) px = p; }
      uint8_t *o = &s_rgba[(y * 496 + x) * 4];
      o[0] = px & 0xff; o[1] = (px >> 8) & 0xff; o[2] = (px >> 16) & 0xff; o[3] = 255;
      hash = (hash ^ (px & 0xffffff)) * 16777619u;
    }
  return hash;
}

extern "C" {

D2_EXPORT float *d2_audio_ptr() { return s_audioOut.data(); }
D2_EXPORT int d2_audio_len() { return (int)s_audioOut.size(); }
D2_EXPORT void d2_audio_clear() { s_audioOut.clear(); }

D2_EXPORT uint8_t *d2_frame2d() { Composite2D(); return s_rgba; }

D2_EXPORT void d2_dump2d(const char *path)
{
  uint32_t h = Composite2D();
  FILE *f = fopen(path, "wb"); if (!f) return;
  fprintf(f, "P6\n496 384\n255\n");
  for (int i = 0; i < 496 * 384; i++) fwrite(&s_rgba[i * 4], 1, 3, f);
  fclose(f);
  printf("[2d] frame %u -> %s (hash %08x)\n", s_frame, path, h);
}


// Boots the machine. Returns 0 on success.
D2_EXPORT
int d2_init(const char *zip, const char *xml, const char *nvram)
{
  s_gameXMLFilePath = xml;
  s_nvramPath = nvram;
  double t0 = nowMs();
  Util::Config::MergeINISections(&s_config, DefaultConfig(), Util::Config::Node("Global"));
  // Single-threaded, no network, no outputs: same settings the browser will need.
  s_config.Get("MultiThreaded").SetValue(false);
  s_config.Get("GPUMultiThreaded").SetValue(false);
  // Net board present; with LINK ID = SINGLE the game never starts it.
  s_config.Get("Network").SetValue(true);
  s_config.Get("SimulateNet").SetValue(true);
  s_config.Get("Throttle").SetValue(false);
  s_config.Get("QuadRendering").SetValue(false);   // WebGL2 has no geometry shaders: triangle path
  // Gamepad pedals: right trigger -> RZ axis, left trigger -> Z axis (analog), plus the keys.
  s_config.Get("InputAccelerator").SetValue(std::string("KEY_UP,JOY1_RZAXIS_POS"));
  s_config.Get("InputBrake").SetValue(std::string("KEY_DOWN,JOY1_ZAXIS_POS"));

  GameLoader loader(xml);
  Game game; ROMSet roms;
  if (loader.Load(&game, &roms, zip)) { printf("[boot] could not load romset %s\n", zip); return 1; }
  printf("[boot] romset: %s (%s) %s %u, %s\n", game.title.c_str(), game.name.c_str(), game.manufacturer.c_str(), game.year,
         Game::SteppingName(game.stepping));
  double tLoad = nowMs();

  auto sys = std::shared_ptr<CInputSystem>(new CScriptInputSystem());
  s_inputs = new CInputs(sys);
  if (!s_inputs->Initialize()) { printf("[boot] inputs init failed\n"); return 2; }
  s_inputs->LoadFromConfig(s_config);

  s_emu = new CModel3(s_config, s_inputs, nullptr, nullptr);
  if (Result::OKAY != s_emu->Init(game, roms)) { printf("[boot] CModel3::Init failed\n"); return 3; }
  roms = ROMSet();
  LoadNVRAM();
  s_r2d = new CRender2D(s_config);
  s_emu->AttachRenderers(s_r2d, &s_r3d, nullptr);
  s_emu->Reset();
  printf("[boot] romset decode %.0f ms, machine init %.0f ms\n", tLoad - t0, nowMs() - tLoad);
  return 0;
}

// Runs n frames; returns wall-clock ms spent.
D2_EXPORT
double d2_run(unsigned n)
{
  double t = nowMs();
  for (unsigned i = 0; i < n; i++, s_frame++)
  {
    while (s_scriptPos < s_script.size() && s_script[s_scriptPos].frame <= s_frame)
    {
      const Step &st = s_script[s_scriptPos++];
      s_keyDown[st.key] = st.down;
      printf("[input] frame %u %s %s\n", s_frame, kKeys[st.key], st.down ? "down" : "up");
    }
    s_inputs->Poll(&s_emu->GetGame(), 0, 0, 496, 384);
    s_emu->RunFrame();
    static const char *shots = getenv("D2_SHOTS");   // "frame,frame,..." extra 2D dumps
    if (shots && getenv("D2_DUMP"))
    {
      std::string key = "," + std::to_string(s_frame + 1) + ",";
      if (("," + std::string(shots) + ",").find(key) != std::string::npos)
        d2_dump2d((std::string(getenv("D2_DUMP")) + "/s" + std::to_string(s_frame + 1) + ".ppm").c_str());
    }
  }
  return nowMs() - t;
}

#ifdef D2_VIDEO
// Phase 1: attach Supermodel's real renderers (New3D + Render2D + SuperAA) to
// the WebGL2 context the page made current. w,h = canvas size in pixels; the
// picture keeps the 496:384 Model 3 aspect and is centred.
static SuperAA *s_saa = nullptr;
static New3D::CNew3D *s_n3d = nullptr;

// Forwards everything to New3D, but can skip the drawing itself (frame skip)
// while still applying texture uploads and memory snapshots, so the emulated
// machine never loses state. Also measures how long the draw takes.
class CProxy3D : public IRender3D
{
public:
  IRender3D *in = nullptr;
  bool skip = false;
  double drawMs = 0; unsigned draws = 0;
  void RenderFrame() override { if (skip) return; double t = nowMs(); in->RenderFrame(); drawMs += nowMs() - t; draws++; }
  void BeginFrame() override { in->BeginFrame(); }
  void EndFrame() override { in->EndFrame(); }
  void UploadTextures(unsigned l, unsigned x, unsigned y, unsigned w, unsigned h) override { s_cnt.texUploads++; in->UploadTextures(l, x, y, w, h); }
  void AttachMemory(const uint32_t *a, const uint32_t *b, const uint32_t *c, const uint32_t *d, const uint16_t *e) override { in->AttachMemory(a, b, c, d, e); }
  void SetStepping(Game::Stepping st) override { in->SetStepping(st); }
  Result Init(unsigned a, unsigned b, unsigned c, unsigned d, unsigned e, unsigned f, unsigned g) override { return in->Init(a, b, c, d, e, f, g); }
  void SetSunClamp(bool e) override { in->SetSunClamp(e); }
  void SetBlockCulling(bool e) override { in->SetBlockCulling(e); }
  float GetLosValue(int l) override { return in->GetLosValue(l); }
  void SetVROMIsPolygonRAM(bool e) override { in->SetVROMIsPolygonRAM(e); }
  void SetScreenSize(float w, float h) override { in->SetScreenSize(w, h); }
};
static CProxy3D s_proxy;
static bool s_skip2d = false;

// skip3d: 1 = run the machine but do not draw the 3D scene (2D still drawn).
D2_EXPORT void d2_skip3d(int on) { s_proxy.skip = on != 0; }
D2_EXPORT double d2_draw_ms() { double r = s_proxy.draws ? s_proxy.drawMs / s_proxy.draws : 0; s_proxy.drawMs = 0; s_proxy.draws = 0; return r; }
D2_EXPORT int d2_video_init(int w, int h)
{
  unsigned xRes = w, yRes = h;
  if (w * 384 > h * 496) xRes = h * 496 / 384; else yRes = w * 384 / 496;
  unsigned xOff = (w - xRes) / 2, yOff = (h - yRes) / 2;
  if (s_n3d) { delete s_n3d; s_n3d = nullptr; }
  if (s_saa) { delete s_saa; s_saa = nullptr; }
  s_saa = new SuperAA(1, CRTcolor::None);
  s_saa->Init(w, h);
  if (Result::OKAY != s_r2d->Init(xOff, yOff, xRes, yRes, w, h, s_saa->GetTargetID(), UpscaleMode::Bilinear)) return 1;
  s_n3d = new New3D::CNew3D(s_config, s_emu->GetGame().name);
  if (Result::OKAY != s_n3d->Init(xOff, yOff, xRes, yRes, w, h, s_saa->GetTargetID())) return 2;
  s_proxy.in = s_n3d;
  s_emu->AttachRenderers(s_r2d, &s_proxy, s_saa);
  printf("[video] WebGL2: lienzo %dx%d, imagen %ux%u (x%.2f de 496x384), New3D + Render2D de Supermodel\n", w, h, xRes, yRes, xRes / 496.0);
  return 0;
}
#endif

D2_EXPORT void d2_save_nvram(const char *path) { SaveNVRAM(path); }

// Machine reset (like the cabinet's power switch); NVRAM is kept.
D2_EXPORT void d2_reset() { s_emu->Reset(); printf("[boot] reset\n"); }

// Gamepad: axis 0..7 (X steering, Z brake, RZ accelerator), buttons 0..31.
D2_EXPORT void d2_joy_axis(int a, int v) { if (a >= 0 && a < 8) s_joyAxis[a] = std::max(-32768, std::min(32767, v)); }
D2_EXPORT void d2_joy_button(int b, int down) { if (b >= 0 && b < 32) s_joyBtn[b] = down != 0; }

D2_EXPORT
void d2_key(const char *name, int down) { int k = keyIndex(name); if (k >= 0) s_keyDown[k] = down != 0; }

D2_EXPORT
void d2_script(const char *s) { ParseScript(s); }

D2_EXPORT
void d2_stats()
{
  printf("[stats] frame %u  3D frames %llu  texture uploads %llu  audio samples %llu (mean |amp| %.4f)\n",
         s_frame, s_cnt.r3d, s_cnt.texUploads, s_audioSamples,
         s_audioSamples ? s_audioEnergy / (2.0 * s_audioSamples) : 0.0);
}

} // extern "C"

#ifndef D2_NO_MAIN
int main(int argc, char **argv)
{
  const char *zip = argc > 1 ? argv[1] : "dayto2pe.zip";
  unsigned frames = argc > 2 ? (unsigned)atoi(argv[2]) : 600;
  const char *xml = argc > 3 ? argv[3] : "Config/Games.xml";
  const char *nv = argc > 4 ? argv[4] : "NVRAM/dayto2pe.nv";
  if (argc > 5) ParseScript(argv[5]);
  if (d2_init(zip, xml, nv)) return 1;
  const unsigned chunk = 60;
  double total = 0;
  for (unsigned done = 0; done < frames; done += chunk)
  {
    double ms = d2_run(std::min(chunk, frames - done));
    total += ms;
    printf("[perf] frames %4u-%4u: %7.1f ms -> %6.1f emulated fps (%.0f%% of 57.524 Hz)\n", done, done + chunk - 1, ms,
           chunk * 1000.0 / ms, chunk * 1000.0 / ms / 57.524 * 100);
    d2_stats();
    const char *dump = getenv("D2_DUMP");   // directory for PPM dumps of the real 2D layers
    if (dump && ((done + chunk) % 300 == 0 || done + chunk >= frames))
      d2_dump2d((std::string(dump) + "/f" + std::to_string(done + chunk) + ".ppm").c_str());
  }
  if (getenv("D2_SAVE_NV")) SaveNVRAM(getenv("D2_SAVE_NV"));
  printf("[perf] TOTAL %u frames in %.0f ms = %.1f fps average\n", frames, total, frames * 1000.0 / total);
  return 0;
}
#endif
