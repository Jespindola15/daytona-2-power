#!/bin/bash
# Builds the headless harness from Supermodel sources.
#   ./build.sh native  -> out/native/headless       (g++)
#   ./build.sh wasm    -> out/wasm/headless.js/.wasm (Emscripten)
# SM = path to a Supermodel checkout (GPLv3, https://github.com/trzy/Supermodel)
set -e
MODE=${1:-native}
HERE=$(cd "$(dirname "$0")" && pwd)
SM=${SM:-$HERE/../third_party/Supermodel}
OUT=$HERE/out/$MODE; mkdir -p $OUT/obj
ZL=${ZL:-$HERE/../third_party/zlib}
INC="-I$HERE/shim -I$SM/Src -I$SM/Src/OSD -I$SM/Src/OSD/SDL -I$SM/Src/Pkgs -I$SM/Src/Graphics -I$SM/Src/Model3 -I$SM/Src/CPU/68K/Musashi -I$HERE/gen -I$HERE"
DEFS="-DGLEW_STATIC -DNET_BOARD"
if [ "$MODE" = wasm ] || [ "$MODE" = web ]; then
  INC="$INC -I$ZL"
  CXX=em++; CC=emcc; OPT="-O3"; CXXEXTRA="-include algorithm -include type_traits -include cstring"
else
  CXX=g++; CC=gcc; OPT="-O3"
fi
SRCS=$(sed "s#^#$SM/#" $HERE/sources.txt)
{ [ "$MODE" = wasm ] || [ "$MODE" = web ]; } && SRCS="$SRCS $(ls $ZL/{adler32,crc32,inflate,inffast,inftrees,zutil,uncompr}.c)"
if [ "$MODE" = web ]; then
  INC="-I$HERE/webshim $INC"
  DEFS="$DEFS -DD2_VIDEO -DD2_NO_MAIN -DglShaderSource=d2_glShaderSource"
  SRCS="$SRCS $(sed "s#^#$SM/#" $HERE/sources_video.txt) $HERE/net_stub.cpp $HERE/video_web.cpp $HERE/headless.cpp"
else
  SRCS="$SRCS $HERE/net_stub.cpp $HERE/SoftRender2D.cpp $HERE/headless.cpp"
fi
OBJS=""
pids=()
for f in $SRCS; do
  o=$OUT/obj/$(basename ${f%.*}).o; OBJS="$OBJS $o"
  if [ ! -f $o ] || [ $f -nt $o ]; then
    ( if [ "${f##*.}" = c ]; then $CC $OPT $DEFS $INC -w -c $f -o $o; else $CXX -std=c++17 $CXXEXTRA $OPT $DEFS $INC -w -c $f -o $o; fi || echo "FAILED $f" ) &
    pids+=($!); if [ ${#pids[@]} -ge ${JOBS:-4} ]; then wait ${pids[0]}; pids=("${pids[@]:1}"); fi
  fi
done
MUS="-DINLINE=static\ inline"
for f in $SM/Src/CPU/68K/Musashi/m68kcpu.c $HERE/gen/m68kopac.c $HERE/gen/m68kopdm.c $HERE/gen/m68kopnz.c $HERE/gen/m68kops.c; do
  o=$OUT/obj/$(basename ${f%.*}).o; OBJS="$OBJS $o"
  [ -f $o ] || $CC $OPT -DINLINE="static inline" $INC -w -c $f -o $o &
done
wait
if [ "$MODE" = web ]; then
  em++ $OBJS -O3 -o $OUT/d2core.js -sALLOW_MEMORY_GROWTH=1 -sINITIAL_MEMORY=512MB -sMAXIMUM_MEMORY=2GB \
    -sMIN_WEBGL_VERSION=2 -sMAX_WEBGL_VERSION=2 \
    -sEXPORTED_FUNCTIONS=_d2_init,_d2_run,_d2_key,_d2_script,_d2_stats,_d2_save_nvram,_d2_video_init,_d2_shader_errors,_d2_skip3d,_d2_draw_ms,_d2_audio_ptr,_d2_audio_len,_d2_audio_clear,_d2_joy_axis,_d2_joy_button,_d2_reset,_malloc,_free \
    -sEXPORTED_RUNTIME_METHODS=FS,ccall,cwrap,HEAPU8,HEAPF32,GL -sMODULARIZE=1 -sEXPORT_NAME=createD2 \
    -sENVIRONMENT=web,worker -sFORCE_FILESYSTEM=1 -sDISABLE_EXCEPTION_CATCHING=0 ${LDEXTRA}
elif [ "$MODE" = wasm ]; then
  em++ $OBJS -O3 -o $OUT/headless.js -sALLOW_MEMORY_GROWTH=1 -sINITIAL_MEMORY=512MB -sMAXIMUM_MEMORY=2GB \
    -sEXPORTED_FUNCTIONS=_main,_d2_init,_d2_run,_d2_key,_d2_script,_d2_stats,_d2_frame2d,_d2_dump2d,_d2_save_nvram,_malloc,_free \
    -sEXPORTED_RUNTIME_METHODS=FS,ccall,cwrap,HEAPU8,callMain -sMODULARIZE=1 -sEXPORT_NAME=createD2 -sINVOKE_RUN=0 \
    -sENVIRONMENT=web,worker,node -sFORCE_FILESYSTEM=1 -sDISABLE_EXCEPTION_CATCHING=0 ${LDEXTRA}
else
  g++ $OBJS -O3 -o $OUT/headless -lz -lpthread
fi
echo "built $OUT"
