/*
 * video_web.cpp — Phase 1: real Model 3 video in WebGL2.
 *
 * Uses Supermodel's OWN renderers unchanged (CNew3D for the Real3D GPU,
 * CRender2D for the tile generator, SuperAA for the final pass). They target
 * desktop OpenGL 4.1; WebGL2 is OpenGL ES 3.0, so this file adapts at the API
 * boundary instead of forking the renderer:
 *   - every glShaderSource() is routed here (-DglShaderSource=d2_glShaderSource)
 *     and the GLSL 4.10 source is rewritten to GLSL ES 3.00;
 *   - glDrawBuffer() (desktop only) maps to glDrawBuffers();
 *   - depth read-back for line-of-sight (not possible in WebGL) returns "far".
 * GPLv3 (derived from Supermodel).
 */
#undef glShaderSource
#include <GLES3/gl3.h>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <emscripten.h>

static const char *kHeader =
  "#version 300 es\n"
  "precision highp float;\n"
  "precision highp int;\n"
  "precision highp usampler2D;\n"
  "precision highp sampler2D;\n";

// Rewrites that GLSL ES needs and desktop GLSL accepted implicitly.
static const char *kFix[][2] = {
  // ES 3.00: no implicit ivec2 -> vec2
  { "* texSize + texPos)", "* texSize + vec2(texPos))" },
  // ES 3.00: sampler arrays may only be indexed by constants
  { "texBiLinear(textureBank[texturePage],", "texBiLinearP(texturePage," },
  { "texBiLinear(textureBank[(texturePage+1)&1], ivec2(0), ivec2(128),", "texBiLinearP((texturePage+1)&1, ivec2(0), vec2(128.0)," },
  { "vec4 GetTextureValue()\n{",
    "vec4 texBiLinearP(int page, ivec2 wrapMode, vec2 texSize, ivec2 texPos, vec2 texCoord, int level)\n"
    "{\n"
    "\tif (page == 0) return texBiLinear(textureBank[0], wrapMode, texSize, texPos, texCoord, level);\n"
    "\treturn texBiLinear(textureBank[1], wrapMode, texSize, texPos, texCoord, level);\n"
    "}\n\n"
    "vec4 GetTextureValue()\n{" },
};

static void ReplaceAll(std::string &s, const std::string &a, const std::string &b)
{
  for (size_t p = s.find(a); p != std::string::npos; p = s.find(a, p + b.size())) s.replace(p, a.size(), b);
}

std::string D2TranslateGLSL(const std::string &in)
{
  std::string s = in;
  size_t v = s.find("#version 410 core");
  if (v == std::string::npos) return s;                      // already ES or unknown: leave alone
  s = kHeader + s.substr(v + strlen("#version 410 core"));
  for (auto &f : kFix) ReplaceAll(s, f[0], f[1]);
  return s;
}

static int s_shaderErrors = 0;

extern "C" void d2_glShaderSource(GLuint shader, GLsizei count, const GLchar *const *strings, const GLint *lengths)
{
  std::string src;
  for (GLsizei i = 0; i < count; i++)
    src += (lengths && lengths[i] >= 0) ? std::string(strings[i], lengths[i]) : std::string(strings[i]);
  std::string es = D2TranslateGLSL(src);
  const char *p = es.c_str();
  glShaderSource(shader, 1, &p, nullptr);
  glCompileShader(shader);           // compile now to log errors with context (compiling twice is harmless)
  GLint ok = 0; glGetShaderiv(shader, GL_COMPILE_STATUS, &ok);
  if (!ok)
  {
    char log[2048]; glGetShaderInfoLog(shader, sizeof(log), nullptr, log);
    std::printf("[gl] shader ES no compila: %s\n", log);
    s_shaderErrors++;
  }
}

extern "C" void glDrawBuffer(GLenum buf)
{
  glDrawBuffers(1, &buf);
}

extern "C" int d2_shader_errors() { return s_shaderErrors; }

extern "C" void glClearDepth(double d) { glClearDepthf((float)d); }

// The software 2D buffers belong to the headless build; with video they stay empty.
#include <memory>
#include "Model3/TileGenBuffer.h"
std::shared_ptr<TileGenBuffer> g_soft2d[2];
