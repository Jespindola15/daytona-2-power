/*
 * net_stub.cpp — Phase 0: the Model 3 net board LINK (TCP between cabinets in
 * Supermodel) is not available in the browser build. The net board itself
 * (CSimNetBoard/CNetBoard) is still compiled; only the transport is stubbed.
 * In single-cabinet mode (LINK ID = SINGLE) the game never uses it.
 * Phase 3 will replace this with a WebSocket ring through Cloudflare.
 */
#include "Model3/NetBoardLink.h"
#include <cstdio>

CNetBoardLink::CNetBoardLink(std::shared_ptr<CNetServer> server, const std::string &address, uint16_t port)
  : m_server(std::move(server)), m_address(address), m_port(port) { std::printf("[net] link stub (no transport yet)\n"); }
CNetBoardLink::~CNetBoardLink(void) {}
bool CNetBoardLink::Connect(void) { return false; }
bool CNetBoardLink::Connected(void) { return false; }
void CNetBoardLink::Send(const void *, size_t) {}
std::vector<uint8_t> &CNetBoardLink::Receive(void) { m_received.clear(); return m_received; }
bool CNetBoardLink::CheckDataAvailable(void) { return false; }

// Handler registrations are never created without a server.
void CNetServer::Registration::Reset(void) {}
CNetServer::Registration::~Registration(void) {}
