#include <chrono>
#include <thread>
#include "Supermodel.h"
#include "SimNetBoard.h"
#include <OSD/Thread.h>
#include <map>
#include <vector>
#include <cstring>
#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#define D2_EXPORT extern "C" EMSCRIPTEN_KEEPALIVE
#else
#define D2_EXPORT extern "C"
#endif

/*
 * web_netboard.cpp — replaces Src/Model3/SimNetBoard.cpp for the browser.
 *
 * Supermodel's simulated net board passes each machine's comm segment around a
 * RING of TCP links (machine k -> k+1), N blocking hops per frame. Over the
 * internet that multiplies latency by N, so here the ring is replaced by a
 * central relay (Cloudflare Durable Object): every frame each machine sends
 * only its OWN segment; the relay answers with the segments of the other N-1
 * machines in exactly the order the ring would have delivered them
 * (slot j = machine k-j). The game sees the same Comm RAM layout as with the
 * original cable. Nothing blocks inside the emulator: the page only runs the
 * next frame once the relay's data for it has arrived (d2_net_need), and
 * remote data may be up to `delay` frames old to absorb network latency.
 * GPLv3 (derived from Supermodel).
 */
struct WebNet
{
  bool haveCfg = false;
  int index = 0, num = 1, delay = 2;
  std::map<uint32_t, std::vector<uint8_t>> bundles;   // frame -> N-1 segments (slot 1..N-1)
  std::vector<uint8_t> out;                           // outgoing: [u32 frame][segment] ...
  uint32_t frame = 0;                                 // link frames completed (ready state)
  int state = 0;                                      // 0 off 1 start/init 2 testing 3 ready 4 error
  int role = -1;                                      // from the game's LINK ID: 0 master, 1 slave
  uint16_t seg = 0;
  bool broken = false, resetNotice = false;
  unsigned missing = 0;
};
static WebNet g_net;

D2_EXPORT void d2_net_config(int index, int num, int delay) { g_net.index = index; g_net.num = num; g_net.delay = delay < 1 ? 1 : delay; g_net.haveCfg = true; }
D2_EXPORT void d2_net_push(uint32_t frame, const uint8_t *p, int len) { g_net.bundles[frame].assign(p, p + len); }
D2_EXPORT int d2_net_need() { return (g_net.state == 3 && (int)g_net.frame >= g_net.delay) ? (int)(g_net.frame - g_net.delay) : -1; }
D2_EXPORT uint8_t *d2_net_out_ptr() { return g_net.out.data(); }
D2_EXPORT int d2_net_out_len() { return (int)g_net.out.size(); }
D2_EXPORT void d2_net_out_clear() { g_net.out.clear(); }
D2_EXPORT int d2_net_state() { return g_net.state; }
D2_EXPORT int d2_net_role() { return g_net.role; }
D2_EXPORT int d2_net_seg() { return g_net.seg; }
D2_EXPORT uint32_t d2_net_frame() { return g_net.frame; }
D2_EXPORT unsigned d2_net_missing() { return g_net.missing; }
D2_EXPORT void d2_net_break() { g_net.broken = true; }
D2_EXPORT int d2_net_reset_notice() { int r = g_net.resetNotice; g_net.resetNotice = false; return r; }

 // these make 16-bit read/writes much neater
#define RAM16 *(uint16_t*)&RAM
#define CommRAM16 *(uint16_t*)&CommRAM

static const uint64_t netGUID = 0x5bf177da34872;

inline bool CSimNetBoard::IsGame(const char* gameName)
{
	return (m_gameInfo.name == gameName) || (m_gameInfo.parent == gameName);
}

CSimNetBoard::CSimNetBoard(const Util::Config::Node& config, std::shared_ptr<CNetServer> server)
	: m_config(config),
	  m_server(std::move(server))
{
}

CSimNetBoard::~CSimNetBoard(void)
{
	m_quit = true;
}

void CSimNetBoard::SaveState(CBlockFile* SaveState)
{
	
}

void CSimNetBoard::LoadState(CBlockFile* SaveState)
{

}

Result CSimNetBoard::Init(uint8_t* netRAMPtr, uint8_t* netBufferPtr)
{
	RAM = netRAMPtr;
	Buffer = netBufferPtr;

	CommRAM = Buffer;
	externalCommRAM = Buffer + 0x10000;

	m_attached = m_gameInfo.netboard_present && m_config["Network"].ValueAs<bool>();

	if (!m_attached)
		return Result::OKAY;

	if (IsGame("daytona2") || IsGame("harley") || IsGame("scud") || IsGame("srally2") ||
		IsGame("skichamp") || IsGame("spikeout") || IsGame("spikeofe"))
		m_gameType = GameType::one;
	else if (IsGame("lemans24") || IsGame("von2") || IsGame("dirtdvls"))
		m_gameType = GameType::two;
	else
		return ErrorLog("Game not recognized or supported");

	m_state = State::start;

	g_net.state = 1;
	return Result::OKAY;
}

void CSimNetBoard::RunFrame(void)
{
	if (!IsRunning())
		return;

	switch (m_state)
	{
	case State::start:
		g_net.state = 1;
		m_status0 = 0;
		m_status1 = IsGame("dirtdvls") ? 0x4004 : 0xe000;
		m_state = State::init;
		break;

	case State::init:
		memset(CommRAM, 0, 0x20000);
		if (m_gameType == GameType::one)
		{
			if (m_status0 & 0x8000)				// has main board changed this register?
			{
				m_IRQ2ack |= 0x01;				// simulate IRQ 2 ack
				if (m_status0 == 0xf000)
				{
					// initialization complete
					m_status1 = 0;
					CommRAM16[0x72] = FLIPENDIAN16(0x1); // is this necessary?
					m_state = State::testing;
				}
				m_status0 = 0;					// 0 should work for all init subroutines
			}
		}
		else
		{
			// type 2 performs initialization on its own
			m_status1 = 0;
			m_state = State::testing;
			m_counter = 0;
		}
		break;

	case State::testing:
		if (m_gameType == GameType::one)
		{
			m_status0 += 1; // type 1 games require this to be incremented every frame

			g_net.state = 2;
			g_net.role = RAM16[0x400] == 0 ? 0 : 1;
			if (!g_net.haveCfg)
				break;

			uint8_t numMachines = (uint8_t)(g_net.num - 1), machineIndex = (uint8_t)g_net.index;
			if ((machineIndex == 0) != (RAM16[0x400] == 0))
			{
				ErrorLog("link: machine %d has the wrong LINK ID (master must be machine 0)", machineIndex);
				m_state = State::error; g_net.state = 4;
				break;
			}
			if (numMachines == 0)
			{
				ErrorLog("link: no other machines");
				m_state = State::error; g_net.state = 4;
				break;
			}
			printf("[net] enlazada: máquina %d de %d (%s), demora %d cuadros\n", machineIndex + 1, numMachines + 1, machineIndex ? "SLAVE" : "MASTER", g_net.delay);

			m_numMachines = numMachines + 1;

			m_status0 = 0;		// supposed to cycle between 0 and 1 (also 2 for Daytona 2); doesn't seem to matter
			m_status1 = 0x2021 + (numMachines * 0x20) + machineIndex;

			CommRAM16[0x0] = RAM16[0x400];	// 0 if master, 1 if slave
			CommRAM16[0x2] = numMachines;
			CommRAM16[0x4] = machineIndex;

			m_counter = 0;
			CommRAM16[0x6] = 0;

			m_segmentSize = RAM16[0x404];
			g_net.seg = m_segmentSize; g_net.frame = 0; g_net.bundles.clear(); g_net.out.clear(); g_net.state = 3;
			printf("[net] segmento de %u bytes por cuadro\n", m_segmentSize);

			// don't know if these are actually required, but it never hurts to include them
			CommRAM16[0x8] = FLIPENDIAN16(0x100 + m_segmentSize);
			CommRAM16[0xa] = FLIPENDIAN16(RAM16[0x402] - m_segmentSize - 1);
			CommRAM16[0xc] = FLIPENDIAN16(0x100);
			CommRAM16[0xe] = FLIPENDIAN16(RAM16[0x402] - m_segmentSize + 0x200);

			m_state = State::ready;
		}
		else
		{
			ErrorLog("link: type-2 games are not supported in the web build");
			m_state = State::error; g_net.state = 4;
			break;
			// we have to track both playable and non-playable machines for type 2
			struct
			{
				uint8_t total;
				uint8_t playable;
			} numMachines, machineIndex;

			if (RAM16[0x200] == 0)	// master
			{
				// flush receive buffer
				while (m_link->CheckDataAvailable())
					m_link->Receive();

				// check all linked instances have the same GUID
				m_link->Send(&netGUID, sizeof(netGUID));
				auto& recv_data = m_link->Receive();
				if (recv_data.empty())
					break;

				uint64_t testGUID;
				memcpy(&testGUID, recv_data.data(), recv_data.size());
				if (testGUID != netGUID)
					testGUID = 0;

				// send the GUID for one more loop
				m_link->Send(&testGUID, sizeof(testGUID));
				m_link->Receive();

				if (testGUID != netGUID)
				{
					ErrorLog("unable to verify connection. Make sure all machines are using same build!");
					m_state = State::error;
					break;
				}

				// master has indices set to zero
				machineIndex.total = 0; machineIndex.playable = 0;
				m_link->Send(&machineIndex, sizeof(machineIndex));

				// receive back the number of other linked machines
				recv_data = m_link->Receive();
				if (recv_data.empty())
					break;
				memcpy(&numMachines, recv_data.data(), recv_data.size());

				// send the number of other linked machines
				m_link->Send(&numMachines, sizeof(numMachines));
				m_link->Receive();
			}
			else if (RAM16[0x200] < 0x8000)	// slave
			{
				// receive GUID from the previous machine and check it matches
				auto& recv_data = m_link->Receive();
				if (recv_data.empty())
					break;
				uint64_t testGUID;
				memcpy(&testGUID, recv_data.data(), recv_data.size());
				if (testGUID != netGUID)
					testGUID = 0;
				m_link->Send(&testGUID, sizeof(testGUID));

				// one more time, in case a later machine has a GUID mismatch
				recv_data = m_link->Receive();
				if (recv_data.empty())
					break;
				memcpy(&testGUID, recv_data.data(), recv_data.size());
				if (testGUID != netGUID)
					testGUID = 0;
				m_link->Send(&testGUID, sizeof(testGUID));

				if (testGUID != netGUID)
				{
					ErrorLog("unable to verify connection. Make sure all machines are using same build!");
					m_state = State::error;
					break;
				}

				// receive the indices of the previous machine and increment them
				recv_data = m_link->Receive();
				if (recv_data.empty())
					break;
				memcpy(&machineIndex, recv_data.data(), recv_data.size());
				machineIndex.total++; machineIndex.playable++;

				// send our indices to the next machine
				m_link->Send(&machineIndex, sizeof(machineIndex));

				// receive the number of machines
				recv_data = m_link->Receive();
				if (recv_data.empty())
					break;
				memcpy(&numMachines, recv_data.data(), recv_data.size());

				// forward the number of machines
				m_link->Send(&numMachines, sizeof(numMachines));
			}
			else
			{
				// relay/satellite
				
				// receive GUID from the previous machine and check it matches
				auto& recv_data = m_link->Receive();
				if (recv_data.empty())
					break;
				uint64_t testGUID;
				memcpy(&testGUID, recv_data.data(), recv_data.size());
				if (testGUID != netGUID)
					testGUID = 0;
				m_link->Send(&testGUID, sizeof(testGUID));

				// one more time, in case a later machine has a GUID mismatch
				recv_data = m_link->Receive();
				if (recv_data.empty())
					break;
				memcpy(&testGUID, recv_data.data(), recv_data.size());
				if (testGUID != netGUID)
					testGUID = 0;
				m_link->Send(&testGUID, sizeof(testGUID));

				if (testGUID != netGUID)
				{
					ErrorLog("unable to verify connection. Make sure all machines are using same build!");
					m_state = State::error;
					break;
				}

				// receive the indices of the previous machine; don't increment the playable index
				recv_data = m_link->Receive();
				if (recv_data.empty())
					break;
				memcpy(&machineIndex, recv_data.data(), recv_data.size());
				machineIndex.total++;

				// send our indices to the next machine
				m_link->Send(&machineIndex, sizeof(machineIndex));

				// receive the number of machines
				recv_data = m_link->Receive();
				if (recv_data.empty())
					break;
				memcpy(&numMachines, recv_data.data(), recv_data.size());

				// forward the number of machines
				m_link->Send(&numMachines, sizeof(numMachines));

				// indicate that this machine is a relay/satellite
				if (!IsGame("dirtdvls"))
					machineIndex.playable |= 0x80;
			}

			// if there are no other linked machines, only continue if Supermodel is linked to itself
			// there might be more than one machine set to master which would cause glitches
			if ((numMachines.total == 0) && ((port_in != port_out) || (addr_out != "127.0.0.1")))
			{
				ErrorLog("no slave machines detected. Make sure only one machine is set to master!");
				if (IsGame("dirtdvls"))
					m_status1 = 0x8085;	// seems like the netboard code writers really liked their CPU model numbers
				m_state = State::error;
				break;
			}

			m_numMachines = numMachines.total + 1;

			m_status0 = 5;			// probably not necessary
			if (IsGame("dirtdvls"))
				m_status1 = (numMachines.playable << 4) | machineIndex.playable | 0x7400;
			else
				m_status1 = (numMachines.playable << 8) | machineIndex.playable;

			CommRAM16[0x0] = RAM16[0x200];	// master/slave/relay status
			CommRAM16[0x2] = (numMachines.playable << 8) | numMachines.total;
			CommRAM16[0x4] = (machineIndex.playable << 8) | machineIndex.total;

			m_counter = 0;
			CommRAM16[0x6] = 0;

			m_segmentSize = RAM16[0x204];

			// don't know if these are actually required, but it never hurts to include them
			CommRAM16[0x8] = FLIPENDIAN16(0x100 + m_segmentSize);
			CommRAM16[0xa] = FLIPENDIAN16(RAM16[0x206]);
			CommRAM16[0xc] = FLIPENDIAN16(0x100);
			CommRAM16[0xe] = FLIPENDIAN16(RAM16[0x206] + 0x80);

			m_state = State::ready;
		}
		break;

	case State::ready:
		m_counter++;
		CommRAM16[0x6] = FLIPENDIAN16(m_counter);
		
		if (g_net.broken)
		{
			m_state = State::error; g_net.state = 4;
			if (m_gameType == GameType::one)
				m_status1 = 0x40;			// "link broken" message to the main board
			break;
		}
		{
			const uint8_t *own = CommRAM + 0x100;
			const uint32_t f = g_net.frame;
			// 1) own segment out (the page sends it to the relay after this frame)
			size_t o = g_net.out.size();
			g_net.out.resize(o + 4 + m_segmentSize);
			memcpy(&g_net.out[o], &f, 4);
			memcpy(&g_net.out[o + 4], own, m_segmentSize);
			// 2) other machines' segments, `delay` frames old, in ring order
			if ((int)f >= g_net.delay)
			{
				auto it = g_net.bundles.find(f - g_net.delay);
				if (it != g_net.bundles.end() && it->second.size() >= (size_t)(m_numMachines - 1) * m_segmentSize)
					memcpy(CommRAM + 0x100 + m_segmentSize, it->second.data(), (m_numMachines - 1) * m_segmentSize);
				else
					g_net.missing++;
				g_net.bundles.erase(g_net.bundles.begin(), g_net.bundles.upper_bound(f - g_net.delay));
			}
			// 3) the ring also hands each machine its own data back (last slot)
			memcpy(CommRAM + 0x100 + m_numMachines * m_segmentSize, own, m_segmentSize);
			g_net.frame++;
		}

		// swap CommRAM banks
		if (m_commbank)
		{
			m_commbank = false;
			CommRAM = Buffer;
			externalCommRAM = Buffer + 0x10000;
		}
		else
		{
			m_commbank = true;
			CommRAM = Buffer + 0x10000;
			externalCommRAM = Buffer;
		}
		
		break;

	case State::error:
		// do nothing
		break;
	}
}

void CSimNetBoard::Reset(void)
{
	// if netboard was active, send an "empty" packet so the other machines don't get stuck waiting for data
	if (m_state == State::ready)
		g_net.resetNotice = true;
	g_net.state = 1;

	m_running = false;
	m_state = State::start;
}

bool CSimNetBoard::IsAttached(void)
{
	return m_attached;
}

bool CSimNetBoard::IsRunning(void)
{
	return m_attached && m_running;
}

void CSimNetBoard::GetGame(const Game& gameInfo)
{
	m_gameInfo = gameInfo;
}

void CSimNetBoard::ConnectProc(void) {}

uint8_t CSimNetBoard::ReadCommRAM8(unsigned addr)
{
	return externalCommRAM[addr];
}

uint16_t CSimNetBoard::ReadCommRAM16(unsigned addr)
{
	return *(uint16_t*)&externalCommRAM[addr];
}

uint32_t CSimNetBoard::ReadCommRAM32(unsigned addr)
{
	return *(uint32_t*)&externalCommRAM[addr];
}

void CSimNetBoard::WriteCommRAM8(unsigned addr, uint8_t data)
{
	externalCommRAM[addr] = data;
}

void CSimNetBoard::WriteCommRAM16(unsigned addr, uint16_t data)
{
	*(uint16_t*)&externalCommRAM[addr] = data;
}

void CSimNetBoard::WriteCommRAM32(unsigned addr, uint32_t data)
{
	*(uint32_t*)&externalCommRAM[addr] = data;
}

uint16_t CSimNetBoard::ReadIORegister(unsigned reg)
{
	if (!IsRunning())
		return 0;

	switch (reg)
	{
	case 0x00:
		return m_IRQ2ack;
	case 0x88:
		return m_status0;
	case 0x8a:
		return m_status1;
	default:
		ErrorLog("read from unknown IO register 0x%02x", reg);
		return 0;
	}
}

void CSimNetBoard::WriteIORegister(unsigned reg, uint16_t data)
{
	switch (reg)
	{
	case 0x00:
		m_IRQ2ack = data;
		break;
	case 0x88:
		m_status0 = data;
		break;
	case 0x8a:
		m_status1 = data;
		break;
	case 0xc0:
		if (data == 0)
			Reset();
		m_running = (data != 0);
		break;
	default:
		ErrorLog("write to unknown IO register 0x%02x", reg);
	}
}
