/*
 * SoftRender2D.cpp — replaces Src/Graphics/Render2D.cpp in the web/headless
 * build. Supermodel's tile generator (CTileGen) already draws both 2D layers
 * in SOFTWARE into two 512x384 RGBA buffers; the original CRender2D only
 * uploads them to OpenGL. This version keeps the same class/ABI but, instead
 * of OpenGL, exposes the two buffers so the harness (or the browser) can read
 * the real pixels produced by the emulated Model 3 tile generator.
 * GPLv3 (derived from Supermodel).
 */
#include "Graphics/Render2D.h"
#include <cstring>

std::shared_ptr<TileGenBuffer> g_soft2d[2];   // 0 = bottom layer, 1 = top layer

CRender2D::CRender2D(const Util::Config::Node &config) : m_config(config) {}
CRender2D::~CRender2D(void) {}
Result CRender2D::Init(unsigned, unsigned, unsigned, unsigned, unsigned, unsigned, unsigned, UpscaleMode) { return Result::OKAY; }
void CRender2D::BeginFrame(void) {}
void CRender2D::PreRenderFrame(void) {}
void CRender2D::RenderFrameBottom(void) {}
void CRender2D::RenderFrameTop(void) {}
void CRender2D::EndFrame(void) {}
void CRender2D::WriteVRAM(unsigned, uint32_t) {}
void CRender2D::AttachRegisters(const uint32_t *) {}
void CRender2D::AttachPalette(const uint32_t *[2]) {}
void CRender2D::AttachVRAM(const uint8_t *) {}
void CRender2D::AttachDrawBuffers(std::shared_ptr<TileGenBuffer> bottom, std::shared_ptr<TileGenBuffer> top)
{
  m_drawBuffers[0] = bottom; m_drawBuffers[1] = top;
  g_soft2d[0] = bottom; g_soft2d[1] = top;
}

// CRender2D owns a GLSLShader member; without OpenGL it is never used.
GLSLShader::GLSLShader() {}
GLSLShader::~GLSLShader() {}

// Supersampling resolve pass (OpenGL) — not used without a GL renderer.
#include "Graphics/SuperAA.h"
void SuperAA::Draw() {}
