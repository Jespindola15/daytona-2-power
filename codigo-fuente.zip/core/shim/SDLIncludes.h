// Shim for the web/headless build: Supermodel's core only uses SDL for
// error message boxes; the network link is replaced (see net_stub.cpp).
#ifndef INCLUDED_SDLINCLUDES_H
#define INCLUDED_SDLINCLUDES_H
#include <cstdio>
#define SDL_MESSAGEBOX_ERROR 0
#define SDL_ShowSimpleMessageBox(flags, title, msg, win) (std::fprintf(stderr, "[%s] %s\n", (title), (msg)), 0)
#endif
